﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductClient.Models
{
    public class Product
    {
        public int pid { get; set; }
        public string pname { get; set; }
        public float qty { get; set; }
        public float price { get; set; }


    }
}
