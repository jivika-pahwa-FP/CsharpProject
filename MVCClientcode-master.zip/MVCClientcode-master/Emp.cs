﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductClient
{
    public class Emp
    {
        public int Empid { get; set; }
    }
}
